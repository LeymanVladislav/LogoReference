create function user_set_id()
  returns trigger
language plpgsql
as $$
BEGIN
   New.id:=nextval('users_id_seq');
   Return NEW;
 END;
$$;

